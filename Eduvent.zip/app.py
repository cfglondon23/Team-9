# Import flask and datetime module for showing date and time
from flask import Flask, render_template, request, redirect, url_for, jsonify, flash, current_app
from flask_login import LoginManager, login_user, login_required, logout_user, UserMixin, current_user


# Initializing flask app
app = Flask(__name__)

from db_schema import db, User, Event, Volunteers

app.config['SQLALCHEMY_DATABASE_URI'] = f'sqlite:///todo.sqlite'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY'] = b'_5#y2L"F4Q8z\n\xec]/'

db.init_app(app)


resetdb = False
if resetdb:
    with app.app_context():
        # drop everything, create all the tables, then put some data into the tables
        db.drop_all()
        db.create_all()

login_manager = LoginManager()
login_manager.init_app(app)

login_manager.login_view = "login"

login_manager.login_message = "User needs to be logged in to view this page"

login_manager.login_message_category = "warning"


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = User.query.filter_by(username=username).first()
        if user and user.password == password:
            login_user(user)
            return redirect(url_for('home'))
        else:
            flash('Invalid login details')
            return redirect(url_for('login'))
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST', 'PUT'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        role = request.form['roles']
        if (role == "volunteer"):
            volunteer = True
            organisation = False
        else:
            volunteer = False
            organisation = True
        if (User.query.filter_by(username=username).first()):
            flash('Username already exists')
            return redirect(url_for('register'))
        print(volunteer)
        db.session.add(User(username, password, volunteer, organisation))
        db.session.commit()
        return redirect(url_for('login'))
    return render_template('register.html')


@app.route('/home', methods=('GET', 'POST'))
@login_required
def home():
    if current_user.is_organisation:
        if(Event.query.filter_by(school_id=current_user.id).first() == None):
            return render_template('main_school.html', school=True, events=None)
        events = Event.query.filter_by(school_id=current_user.id).all()
        return render_template('main_school.html', events=events, school=True)
    elif current_user.is_volunteer:
        events = Event.query.all()
        vol_events = Volunteers.query.filter_by(user_id=current_user.id).all()
        return render_template('main.html', events=events, school=False)



@app.route('/add_event', methods=('GET', 'POST'))
@login_required
def add_event():
    if current_user.is_organisation == False:
        return redirect(url_for('home'))
    if request.method == 'POST':
        name = request.form['name']
        description = request.form['freeform']
        school = request.form['name_org']
        vol = request.form['num']
        users = User.query.all()
        event = Event(name=name, description=description,amount_of_volunteers_needed=vol, amount_of_volunteers_have=0,name_of_school=school, school_id=current_user.id)
        db.session.add(event)
        db.session.commit()
        return redirect(url_for('home'))
    return render_template('add_event.html')

@app.route('/take_part<int:event_id>', methods=('GET', 'POST'))
@login_required
def take_part(event_id):
    if current_user.is_volunteer == False:
        return redirect(url_for('home'))
    if request.method == 'POST':
        event = Event.query.filter_by(id=event_id).first()
        event.amount_of_volunteers_have += 1
        print("qdqpd")
        db.session.commit()
        return redirect(url_for('home'))
    return redirect(url_for('home'))


@app.route('/', methods=('GET', 'POST'))
@login_required
def index():
    return render_template('welcome.html')

@login_manager.user_loader
def load_user(user_id):
    with current_app.app_context():
        return db.session.get(User, int(user_id))

@app.before_request
def require_login():
    if not current_user.is_authenticated and request.endpoint != 'login' and request.endpoint != 'register':
        return redirect(url_for('login', next=request.endpoint))


@app.route('/logout')
def logout():
    logout_user()
    return redirect(url_for('login'))

# Running app
if __name__ == '__main__':
    app.run(debug=True)
