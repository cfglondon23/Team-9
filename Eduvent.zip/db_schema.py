from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin


# create the database interface
db = SQLAlchemy()

# a model of a user for the database
class User(UserMixin, db.Model):
    __tablename__='users'
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(20), unique=True)
    password = db.Column(db.String(20), unique=False)
    is_volunteer = db.Column(db.Boolean(), nullable=False)
    is_organisation = db.Column(db.Boolean, default=False, nullable=False)
    is_active = db.Column(db.Boolean(), default=True)


    def __init__(self, username, password, is_volunteer, is_organisation):
        self.username = username
        self.password = password
        self.is_volunteer = is_volunteer
        self.is_organisation = is_organisation

class Event(db.Model):
    __tablename__='events'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), nullable=False)
    description = db.Column(db.String(1000), nullable=False)
    amount_of_volunteers_needed = db.Column(db.Integer, nullable=False)
    amount_of_volunteers_have = db.Column(db.Integer, nullable=False)
    name_of_school = db.Column(db.String(50), nullable=False)
    volunteer = db.relationship('Volunteers', backref='Event', lazy=True)
    school_id = db.Column(db.Integer, nullable=False)


class Volunteers(db.Model):
    __tablename__='volunteers'
    id = db.Column(db.Integer, primary_key=True)
    event_id = db.Column(db.Integer, db.ForeignKey('events.id'), nullable=False)
    school_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)



