// $('#registration_form').submit(function() {
//     var username = $('#username').val();
//     var password = $('#password').val();
//     var role = $('#role').val();
//     var result = {'username': username, 'password': password, 'role': role}
//     $.ajax({
//       type: "POST",
//       url: "/register_ajax",
//       data: JSON.stringify(result),
//       contentType: "application/json",
//       dataType: 'json',
//       success: function(response) {
//             console.log(response);
//         }
//     });
// });

$('#login_form').submit(function() {
    var username = $('#username').val();
    var password = $('#password').val();
    var result = {'username': username, 'password': password}
    console.log("task_name:"+username);
    $.ajax({
      type: "POST",
      url: "/login_ajax",
      data: JSON.stringify(result),
      contentType: "application/json",
      dataType: 'json'
    });
});

if (typeof flash_message !== 'undefined') {
        alert(flash_message);
    }
